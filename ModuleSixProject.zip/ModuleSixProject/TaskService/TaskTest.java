package finalproject.finalproject;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("1", "Task1", "This is Task1");
        assertEquals("1", task.getId());
        assertEquals("Task1", task.getName());
        assertEquals("This is Task1", task.getDescription());
    }

    @Test
    public void testTaskCreationWithInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task1", "This is Task1")); // ID longer than 10 characters
    }

    @Test
    public void testTaskCreationWithInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "This name is definitely longer than twenty characters", "This is Task1")); // Name longer than 20 characters
    }

    @Test
    public void testTaskCreationWithInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Task1", "This description is way too long to fit into the fifty character limit")); // Description longer than 50 characters
    }

    @Test
    public void testSetName() {
        Task task = new Task("1", "Task1", "This is Task1");
        task.setName("UpdatedTask1");
        assertEquals("UpdatedTask1", task.getName());
    }

    @Test
    public void testSetNameWithInvalidValue() {
        Task task = new Task("1", "Task1", "This is Task1");
        assertThrows(IllegalArgumentException.class, () -> task.setName("This name is definitely longer than twenty characters")); // Name longer than 20 characters
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("1", "Task1", "This is Task1");
        task.setDescription("Updated description for Task1");
        assertEquals("Updated description for Task1", task.getDescription());
    }

    @Test
    public void testSetDescriptionWithInvalidValue() {
        Task task = new Task("1", "Task1", "This is Task1");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is way too long to fit into the fifty"));
    }
}
