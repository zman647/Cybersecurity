package finalproject.finalproject;


import java.util.*;

public class TaskService {
    private Map<String, Task> taskMap;

    public TaskService() {
        this.taskMap = new HashMap<>();
    }
    //add task with unique id
    public void addTask1(Task task) {
        if(task == null || taskMap.containsKey(task.getId())) {
            throw new IllegalArgumentException("Invalid task or task id");
        }
        taskMap.put(task.getId(), task);
    }
    //delete task
    public void deleteTask(String id) {
        taskMap.remove(id);
    }
    //update task name
    public void updateTaskName(String id, String newName) {
        Task task = taskMap.get(id);
        if(task != null) {
            task.setName(newName);
        }
    }
    //update task description 
    public void updateTaskDescription(String id, String newDescription) {
        Task task = taskMap.get(id);
        if(task != null) {
            task.setDescription(newDescription);
        }
    }

    public Task getTask(String id) {
        return taskMap.get(id);
    }
	public void addTask(Task task1) {
		
		
	}
}
