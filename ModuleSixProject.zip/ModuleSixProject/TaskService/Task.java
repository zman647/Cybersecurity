package finalproject.finalproject;


public class Task {
    private final String id;
    private String name;
    private String description;

    //Less than 10 lines
    public Task(String id, String name, String description) {
        if(id == null || id.length() > 10 || name == null || name.length() > 20 || description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid input values");
        }
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public void Task1(String id2, String name2, String description2) {
		
	}

	public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    //Less than 20
    public void setName(String name) {
        if(name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name value");
        }
        this.name = name;
    }

    public String getDescription() {
        return description;
    }
    //Less than 50
    public void setDescription(String description) {
        if(description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description value");
        }
        this.description = description;
    }
}
