package finalproject.finalproject;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }


    @Test
    public void testAddAppointmentWithDuplicateID() {
        Appointment appointment1 = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");
        Appointment appointment2 = new Appointment("id12345", new Date(System.currentTimeMillis() + 200000), "A different appointment");
        appointmentService.addAppointment(appointment1);
        assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment2));
    }

  //Tests the behavior of Appointment service when the same ID is implemented.

    @Test
    public void testDeleteNonexistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment("nonexistentID"));
    }
//Tests if an appointment is added with invalid ID
}
