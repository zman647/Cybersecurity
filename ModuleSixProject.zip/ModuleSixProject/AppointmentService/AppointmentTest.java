package finalproject.finalproject;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
    
    @Test
    public void testValidConstructor() {
        Appointment appointment = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");

        assertNotNull(appointment);
        assertEquals("id12345", appointment.getAppointmentId());
        assertTrue(appointment.getAppointmentDate().after(new Date()));
        assertEquals("A test appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidConstructorWithLongId() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("id12345678901", new Date(System.currentTimeMillis() + 100000), "A test appointment"));
    }

    @Test
    public void testInvalidConstructorWithPastDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("id12345", new Date(System.currentTimeMillis() - 100000), "A test appointment"));
    }

    @Test
    public void testInvalidConstructorWithNullDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), null));
    }

    @Test
    public void testSetDescription() {
        Appointment appointment = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");
        
        appointment.setDescription("A new description");
        
        assertEquals("A new description", appointment.getDescription());
    }

    @Test
    public void testSetInvalidDescription() {
        Appointment appointment = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");

        assertThrows(IllegalArgumentException.class, () -> appointment.setDescription(null));
    }

    @Test
    public void testSetAppointmentDate() {
        Appointment appointment = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");

        Date newDate = new Date(System.currentTimeMillis() + 200000);
        appointment.setAppointmentDate(newDate);

        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    public void testSetInvalidAppointmentDate() {
        Appointment appointment = new Appointment("id12345", new Date(System.currentTimeMillis() + 100000), "A test appointment");

        assertThrows(IllegalArgumentException.class, () -> appointment.setAppointmentDate(new Date(System.currentTimeMillis() - 100000)));
    }
}

//Was having problems with the time id strings of code from my original not passing coverage. Changed constructor and could not figure out how to improve percentage so I started from scratch and tried to simplify it a little.