package finalproject.finalproject;



import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // Using a HashMap to store contact objects, using the contactId as the key
    private Map<String, Contact> contacts = new HashMap<>();

    // Method to add a contact
    public void addContact(Contact contact) {
        // If the contact already exists in the HashMap, throw an exception
        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact with this ID already exists.");
        }
        // Otherwise, add the contact to the HashMap
        contacts.put(contact.getContactId(), contact);
    }

    // Method to delete a contact
    public void deleteContact(String contactId) {
        // If the contact doesn't exist, throw an exception
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("No contact with this ID exists.");
        }
        // Otherwise, remove the contact from the HashMap
        contacts.remove(contactId);
    }

    // Methods to update contact fields
    public void updateFirstName(String contactId, String newFirstName) {
        Contact contact = getContact(contactId);
        contact.setFirstName(newFirstName);
    }

    public void updateLastName(String contactId, String newLastName) {
        Contact contact = getContact(contactId);
        contact.setLastName(newLastName);
    }

    public void updatePhoneNumber(String contactId, String newPhoneNumber) {
        Contact contact = getContact(contactId);
        contact.setPhoneNumber(newPhoneNumber);
    }

    public void updateAddress(String contactId, String newAddress) {
        Contact contact = getContact(contactId);
        contact.setAddress(newAddress);
    }

    // Helper method to retrieve a contact based on its ID
    public Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("No contact with this ID exists.");
        }
        return contact;
    }
}
