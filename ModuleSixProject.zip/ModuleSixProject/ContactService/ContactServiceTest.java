package finalproject.finalproject;




import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService contactService;
    private Contact validContact;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
        validContact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Test Street");
    }

    @Test
    void addContactWithUniqueID() {
        contactService.addContact(validContact);
        assertEquals(validContact, contactService.getContact(validContact.getContactId()));
    }

    @Test
    void addContactWithDuplicateID() {
        contactService.addContact(validContact);
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(validContact));
    }

    @Test
    void deleteExistingContact() {
        contactService.addContact(validContact);
        contactService.deleteContact(validContact.getContactId());
        assertThrows(IllegalArgumentException.class, () -> contactService.getContact(validContact.getContactId()));
    }

    @Test
    void deleteNonExistingContact() {
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("invalidID"));
    }

    @Test
    void updateExistingContactFirstName() {
        contactService.addContact(validContact);
        contactService.updateFirstName(validContact.getContactId(), "Jane");
        assertEquals("Jane", contactService.getContact(validContact.getContactId()).getFirstName());
    }

    @Test
    void updateNonExistingContactFirstName() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateFirstName("invalidID", "Jane"));
    }

    // Similar test methods for other fields (LastName, PhoneNumber, Address)
    @Test
    void updateExistingContactLastName() {
        contactService.addContact(validContact);
        contactService.updateLastName(validContact.getContactId(), "Smith");
        assertEquals("Smith", contactService.getContact(validContact.getContactId()).getLastName());
    }

    @Test
    void updateNonExistingContactLastName() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateLastName("invalidID", "Smith"));
    }

    @Test
    void updateExistingContactPhoneNumber() {
        contactService.addContact(validContact);
        contactService.updatePhoneNumber(validContact.getContactId(), "0987654321");
        assertEquals("0987654321", contactService.getContact(validContact.getContactId()).getPhoneNumber());
    }

    @Test
    void updateNonExistingContactPhoneNumber() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updatePhoneNumber("invalidID", "0987654321"));
    }

    @Test
    void updateExistingContactAddress() {
        contactService.addContact(validContact);
        contactService.updateAddress(validContact.getContactId(), "456 New Address");
        assertEquals("456 New Address", contactService.getContact(validContact.getContactId()).getAddress());
    }

    //Created more tests in the above to improve test coverage, was having a few problems with updateLastName, updatePhoneNumber, and updateAddress

}
