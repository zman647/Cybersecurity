package finalproject.finalproject;



import org.junit.jupiter.api.*;


import static org.junit.jupiter.api.Assertions.*;



public class ContactTest {
    
    @Test
    public void testCreateContact() {
        // Test creating a valid contact
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testInvalidContactId() {
        // Test creating a contact with an invalid ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
        });
    }

    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", null, "Last", "1234567890", "123 Main St");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "longfirstnameislong", "Last", "1234567890", "123 Main St");
        });
    }

    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "First", null, "1234567890", "123 Main St");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "First", "averyverylonglastname", "1234567890", "123 Main St");
        });
    }


    @Test
    public void testInvalidPhoneNumber() {
        // Test creating a contact with an invalid phone number
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "12345678901", "123 Main St");
        });
    }

    @Test
    public void testInvalidAddress() {
        // Test creating a contact with an invalid address
        String invalidAddress = "1234567890123456789012345678901234567890"; // A string with length 40
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1234567890", "John", "Doe", "1234567890", invalidAddress);
        });
    }

//Tried checking string length at 31, but my problem ended up being with my constructor

    @Test
    public void testSetFirstName() {
        // Test setting a valid first name
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        // Test setting a valid last name
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhoneNumber() {
        // Test setting a valid phone number
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contact.setPhoneNumber("0987654321");
        assertEquals("0987654321", contact.getPhoneNumber());
    }

    @Test
    public void testSetAddress() {
        // Test setting a valid address
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contact.setAddress("321 Main St");
        assertEquals("321 Main St", contact.getAddress());
    }


    @Test
    void testSetInvalidFirstName() {
        Contact contact = new Contact("1234567890", "First", "Last", "1234567890", "123 Main St");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("longfirstnameislong");
        });
    }

    @Test
    void testSetInvalidLastName() {
        Contact contact = new Contact("1234567890", "First", "Last", "1234567890", "123 Main St");

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("averyverylonglastname");
        });
    }


    @Test
    public void testSetInvalidPhoneNumber() {
        // Test setting an invalid phone number
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhoneNumber("12345678901");
        });
    }

    @Test
    public void testSetInvalidAddress() {
        // Test setting an invalid address
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("1234567890123456789012345678901");
        });
    }
}
